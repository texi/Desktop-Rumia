import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
public class win
{
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				MyFrame frame=new MyFrame();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}

class sendInfo
{
	public int type;
	public String info;

	public sendInfo(int x1,String x2)
	{
		this.type=x1;
		this.info=x2;
	}
}

class MyFrame extends JFrame
{
	private ArrayBlockingQueue<sendInfo> queue=new ArrayBlockingQueue<sendInfo>(30);

	private int F_WIDTH;
	private int F_HEIGHT;
	private int nowx,nowy,status=0,energy=100;

	static private JFrame here;
	private JLabel rumia;
	private JPanel jpp;
	private int direction=0;//0 to left

	private ImageIcon left_stand,left_run1,left_run2, 
			right_stand,right_run1,right_run2,look,look2, 
			run1,run2,run3,run12,run22,run32,//walk and stand
			left_fly,right_fly,left_down,right_down, //fly and stop
			left_sit_normal,right_sit_normal, //normal sit
			hah1,hah2,hah3,hah4,hah5,hah12,hah22,hah32,hah42,hah52, //tired and hah
			left_sano,right_sano,//look at the sky
			shink1,shink2,shink3,shink4,shink12,shink22,shink32,shink42,slinkk,slinkk2,//play leg
			b1,b2,b3,b4,b5,b6,b7,b8,b9,//blackball
			s1,s2,s3,s4,s5,s12,s22,s32,s42,s52;//sleep

	public MyFrame()
	{
		this.here=this;
		String laf = "javax.swing.plaf.nimbus.NimbusLookAndFeel";  
        try {  
            UIManager.setLookAndFeel(laf);  
            SwingUtilities.updateComponentTreeUI(this);  
        } catch (Exception e) {
            e.printStackTrace();  
        }

        addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});

        //move
        run1=new ImageIcon("material/move/run.png");run12=new ImageIcon("material/move/run12.png");
        run2=new ImageIcon("material/move/run2.png");run22=new ImageIcon("material/move/run22.png");
        run3=new ImageIcon("material/move/run3.png");run32=new ImageIcon("material/move/run32.png");
        left_stand=new ImageIcon("material/move/shime1.png");right_stand=new ImageIcon("material/move/shime12.png");
        left_run1=new ImageIcon("material/move/shime2.png");right_run1=new ImageIcon("material/move/shime22.png");
		left_run2=new ImageIcon("material/move/shime3.png");right_run2=new ImageIcon("material/move/shime32.png");
		left_fly=new ImageIcon("material/move/shime4.png");right_fly=new ImageIcon("material/move/shime42.png");
		left_down=new ImageIcon("material/move/shime5.png");right_down=new ImageIcon("material/move/shime52.png");
		look=new ImageIcon("material/move/look.png");look2=new ImageIcon("material/move/look2.png");
		//sit
		left_sit_normal=new ImageIcon("material/sit/normal.png");right_sit_normal=new ImageIcon("material/sit/normal2.png");
		hah1=new ImageIcon("material/sit/hah1.png");hah12=new ImageIcon("material/sit/hah12.png");
		hah2=new ImageIcon("material/sit/hah2.png");hah22=new ImageIcon("material/sit/hah22.png");
		hah3=new ImageIcon("material/sit/hah3.png");hah32=new ImageIcon("material/sit/hah32.png");
		hah4=new ImageIcon("material/sit/hah4.png");hah42=new ImageIcon("material/sit/hah42.png");
		hah5=new ImageIcon("material/sit/hah5.png");hah52=new ImageIcon("material/sit/hah52.png");
		left_sano=new ImageIcon("material/sit/sano.png");right_sano=new ImageIcon("material/sit/sano2.png");
		shink1=new ImageIcon("material/sit/shink.png");shink12=new ImageIcon("material/sit/shink12.png");
		shink2=new ImageIcon("material/sit/shink2.png");shink22=new ImageIcon("material/sit/shink22.png");
		shink3=new ImageIcon("material/sit/shink3.png");shink32=new ImageIcon("material/sit/shink32.png");
		shink4=new ImageIcon("material/sit/shink4.png");shink42=new ImageIcon("material/sit/shink42.png");
		slinkk=new ImageIcon("material/sit/slinkk.png");slinkk2=new ImageIcon("material/sit/slinkk2.png");
		//sleep
		s1=new ImageIcon("material/sleep/s1.png");s12=new ImageIcon("material/sleep/s12.png");
		s2=new ImageIcon("material/sleep/s2.png");s22=new ImageIcon("material/sleep/s22.png");
		s3=new ImageIcon("material/sleep/s3.png");s32=new ImageIcon("material/sleep/s32.png");
		s4=new ImageIcon("material/sleep/s4.png");s42=new ImageIcon("material/sleep/s42.png");
		s5=new ImageIcon("material/sleep/s5.png");s52=new ImageIcon("material/sleep/s52.png");		
		//black ball
		b1=new ImageIcon("material/black/b1.png");
		b2=new ImageIcon("material/black/b2.png");
		b3=new ImageIcon("material/black/b3.png");
		b4=new ImageIcon("material/black/b4.png");
		b5=new ImageIcon("material/black/bb.png");
		b6=new ImageIcon("material/black/bb2.png");
		b7=new ImageIcon("material/black/bb3.png");
		b8=new ImageIcon("material/black/bb4.png");
		b9=new ImageIcon("material/black/bb5.png");

		//get the width and height of the screen
		Dimension screensize=Toolkit.getDefaultToolkit().getScreenSize();
		F_WIDTH=screensize.width;
		F_HEIGHT=screensize.height;

        //setDefaultLookAndFeelDecorated(true);
		setResizable(false);
		setUndecorated(true);
		setLocation(F_WIDTH/2,F_HEIGHT/2);
		setSize(128,128);
		setBackground(new Color(0,0,0,0));
		setType(JFrame.Type.UTILITY);
		this.setAlwaysOnTop(true); 

		//set the bg
		this.jpp=new JPanel();
		jpp.setOpaque(false);
		jpp.setLayout(null);

		//show the start image
		rumia=new JLabel(left_stand);
		rumia.setBounds(0,0,128,128);

		//add the pop menu
		JPopupMenu pm=new JPopupMenu();
		JMenuItem it1=new JMenuItem("摸头");
		it1.addActionListener(new java.awt.event.ActionListener(){
			public void actionPerformed(java.awt.event.ActionEvent evt){
				try
				{queue.put(new sendInfo(1,"touchHead"));}
				catch(InterruptedException e){return;}
			}
		});
		JMenuItem it2=new JMenuItem("退出");
		it2.addActionListener(new java.awt.event.ActionListener(){
			public void actionPerformed(java.awt.event.ActionEvent evt){
				System.exit(0);
			}
		});
		pm.add(it1);
		pm.add(it2);

		jpp.addMouseListener(new MouseAdapter()  {  
	        public void mouseReleased(MouseEvent e)  
	        {  
	            if(e.isPopupTrigger())  
	            {  
	                pm.show(jpp,e.getX(),e.getY());  
	            }  
	        }  
    	});

    	//add the component 
		jpp.add(rumia);
		jpp.add(pm);
		add(this.jpp);

		nowx=F_WIDTH/2;
		nowy=F_HEIGHT/2;

		Runnable r2=new rumiaCPU();
		Thread t2=new Thread(r2);
		t2.start();

		Runnable r=new rumiaMove();
		Thread t=new Thread(r);
		t.start();
	}

	//let rumia to talk
	private class rumiaTalk implements Runnable
	{
		private String str;
		private int gap;

		public rumiaTalk(int x,String info)
		{
			this.gap=x;
			this.str=info;
		}

		public void run()
		{
			try
			{
				talk talkWin=new talk(str);
				Thread.sleep(gap);
				talkWin.dispose();
			}catch(InterruptedException e){return;}
		}
	}

	private void speak(int x,String info)
	{
		Runnable r=new rumiaTalk(x,info);
		Thread t=new Thread(r);
		t.start();
	}

	private class rumiaCPU implements Runnable
	{
		private sendInfo si;
		public void run()
		{
			try
			{
				while(true)
				{
					si=queue.take();
					switch(si.type)
					{
						case 1:
						{
							speak(3000,"nia~nia~nia~");
							break;
						}
						default:;
					}
				}
			}catch(InterruptedException e){return;}
		}
	}

	private class rumiaMove implements Runnable
	{
		private Random random=new Random();
		private int v,mod,flag;
		public void run()
		{
			while(true)
			{
				try
				{
					//move status
					if(status==0)
					{
						mod=random.nextInt(10);
						//left walk
						if(mod==1)
						{
							if(direction==1)
							{
								act(left_stand);
								direction=0;
							}

							int walkx=random.nextInt(200);
							if(nowx-walkx<0)
							{
								walkx=nowx;
							}
							//tary=random.nextInt(600);
							int x=0;
							for(flag=0;x<=walkx;x+=5)
							{
								Thread.sleep(200);
								switch(flag)
								{
									case 0:act(left_run1);flag++;break;
									case 1:act(left_stand);flag++;break;
									case 2:act(left_run2);flag++;break;
									case 3:act(left_stand);flag=0;break;
								}
								here.setLocation(nowx-x,nowy);
							}
							nowx-=x;
							act(left_stand);
						}
						//right walk
						else if(mod==2)
						{
							if(direction==0)
							{
								act(right_stand);
								direction=1;
							}

							int walkx=random.nextInt(200);
							if(nowx+walkx+128>F_WIDTH)
							{
								walkx=F_WIDTH-nowx-128;
							}
							int x=0;
							for(flag=0;x<=walkx;x+=5)
							{
								Thread.sleep(200);
								switch(flag)
								{
									case 0:act(right_run1);flag++;break;
									case 1:act(right_stand);flag++;break;
									case 2:act(right_run2);flag++;break;
									case 3:act(right_stand);flag=0;break;
								}
								here.setLocation(nowx+x,nowy);
							}
							nowx+=x;
							act(right_stand);
						}
						//fly up
						else if(mod==3)
						{
							if(direction==0)
								act(left_fly);
							else
								act(right_fly);
							int walky=random.nextInt(300);
							if(nowy-walky<0)
							{
								walky=nowy;
							}
							int y=0;
							for(flag=0;y<=walky;y+=5)
							{
								Thread.sleep(100);
								here.setLocation(nowx,nowy-y);
							}
							nowy-=y;
							if(direction==0)
								actMore(150,left_down,left_stand);
							else
								actMore(150,right_down,right_stand);
						}
						//fly down
						else if(mod==4)
						{
							if(direction==0)
								act(left_fly);
							else
								act(right_fly);
							int walky=random.nextInt(400);
							if(nowy+walky+128>F_HEIGHT)
							{
								walky=F_HEIGHT-nowy-128;
							}
							int y=0;
							for(flag=0;y<=walky;y+=5)
							{
								Thread.sleep(100);
								here.setLocation(nowx,nowy+y);
							}
							nowy+=y;
							if(direction==0)
								actMore(150,left_down,left_stand);
							else
								actMore(150,right_down,right_stand);
						}
						//switch status to sit
						else if(mod==5)
						{
							//sit
							status=1;
							if(direction==0)
								act(left_sit_normal);
							else
								act(right_sit_normal);
						}
						//run left
						if(mod==6)
						{
							if(direction==1)
							{
								act(run3);
								direction=0;
							}

							int walkx=random.nextInt(300);
							if(nowx-walkx<0)
							{
								walkx=nowx;
							}
							//tary=random.nextInt(600);
							int x=0;
							for(flag=0;x<=walkx;x+=8)
							{
								Thread.sleep(100);
								switch(flag)
								{
									case 0:act(run1);flag++;break;
									case 1:act(run3);flag++;break;
									case 2:act(run2);flag++;break;
									case 3:act(run3);flag=0;break;
								}
								here.setLocation(nowx-x,nowy);
							}
							nowx-=x;
							actMore(200,run3,left_stand);
						}
						//run right
						else if(mod==7)
						{
							if(direction==0)
							{
								act(right_stand);
								direction=1;
							}

							int walkx=random.nextInt(300);
							if(nowx+walkx+128>F_WIDTH)
							{
								walkx=F_WIDTH-nowx-128;
							}
							int x=0;
							for(flag=0;x<=walkx;x+=8)
							{
								Thread.sleep(100);
								switch(flag)
								{
									case 0:act(run12);flag++;break;
									case 1:act(run32);flag++;break;
									case 2:act(run22);flag++;break;
									case 3:act(run32);flag=0;break;
								}
								here.setLocation(nowx+x,nowy);
							}
							nowx+=x;
							actMore(200,run32,right_stand);
						}
						//super~black~ball!!!!!!
						else if(mod==8)
						{
							if(energy>=20)
								status=3;
						}
						else
						{
							if(direction==0)
								act(look);
							else
								act(look2);
							Thread.sleep((1+random.nextInt(2))*1000);
							if(direction==0)
								act(left_stand);
							else
								act(right_stand);
						}
						energy-=3;
					}
					//sit status
					else if(status==1)
					{
						mod=random.nextInt(8);
						//switch status to move
						if(mod==1)
						{
							status=0;
							if(direction==0)
								act(left_stand);
							else
								act(right_stand);
						}
						//hah~~(tired)
						else if(mod==2&&energy<60)
						{
							if(direction==0)
							{
								actMore(300,hah1,hah2);
								Thread.sleep(1000);
								actMore(300,hah3,hah4,hah5,left_sit_normal);
							}
							else
							{
								actMore(300,hah12,hah22);
								Thread.sleep(1000);
								actMore(300,hah32,hah42,hah52,right_sit_normal);
							}
							Thread.sleep((1+random.nextInt(2))*1000);
						}
						//comes up a good idea
						else if(mod==3)
						{
							if(direction==0)
								act(left_sano);
							else
								act(right_sano);
							Thread.sleep((1+random.nextInt(2))*1000);
						}
						//shrink legs
						else if(mod==4)
						{
							int t=random.nextInt(15);
							if(direction==0)
							{
								act(shink1);
								Thread.sleep(800);
								//deal with the Y wrong
								here.setLocation(nowx,nowy+15);
								act(shink2);
								for(int i=0;i<t;i++)
								{
									actMore(400,shink3,shink2,shink4,shink2);
									if(random.nextInt(4)==1)
									{
										act(slinkk);
										Thread.sleep((1+random.nextInt(3))*1000);
									}
								}
								act(shink2);
								here.setLocation(nowx,nowy);
							}
							else
							{
								act(shink12);
								Thread.sleep(800);
								here.setLocation(nowx,nowy+15);
								act(shink22);
								for(int i=0;i<t;i++)
								{
									actMore(400,shink32,shink22,shink42,shink22);
									if(random.nextInt(4)==1)
									{
										act(slinkk2);
										Thread.sleep((1+random.nextInt(3))*1000);
									}
								}
								act(shink22);
								here.setLocation(nowx,nowy);
							}
						}
						//go to sleep
						else if(mod==5)
						{
							if(energy<30)
								status=2;
						}
						else
						{
							if(direction==0)
								act(left_sit_normal);
							else
								act(right_sit_normal);
							Thread.sleep((2+random.nextInt(8))*1000);
						}
						energy-=2;
					}
					//sleep status
					else if(status==2)
					{
						//refill the energy
						energy=energy+40+random.nextInt(60);
						int t=30+random.nextInt(40);
						if(direction==0)
						{
							act(s1);
							for(int i=0;i<=t;i++)
							{
								Thread.sleep(1000);
								if(i%6==0)
								{
									switch(random.nextInt(4))
									{
										case 0:act(s2);break;
										case 1:act(s3);break;
										case 2:act(s4);break;
										case 3:act(s5);break;
										default:;
									}
								}
							}
							actMore(200,s1,left_sit_normal);
							Thread.sleep(1000);
						}
						else
						{
							act(s12);
							for(int i=0;i<=t;i++)
							{
								Thread.sleep(1000);
								if(i%6==0)
								{
									switch(random.nextInt(4))
									{
										case 0:act(s22);break;
										case 1:act(s32);break;
										case 2:act(s42);break;
										case 3:act(s52);break;
										default:;
									}
								}
							}
							actMore(200,s12,right_sit_normal);
							Thread.sleep(1000);
						}
						status=1;
					}
					//super black ball mod
					else if(status==3)
					{
						actMore(300,b1,b2,b3,b4,b5,b6,b7,b8,b9);
						nowx=random.nextInt(F_WIDTH-128);
						nowy=random.nextInt(F_HEIGHT-128);
						here.setLocation(nowx,nowy);
						actMore(300,b9,b8,b7,b6,b5,b4,b3,b2,b1);
						energy-=5;
						status=1;
					}
					//if the enegy run out
					if(energy<10)
					{
						if(status!=1)
						{
							if(direction==0)
								act(left_sit_normal);
							else
								act(right_sit_normal);
						}
						status=2;
					}
				}
				catch(InterruptedException e){return ;}
			}
		}
	}

	//function to set the move(picture)
	private void act(ImageIcon move)
	{
		this.rumia.setIcon(move);
		//this.jpp.updateUI();
	}

	//function to show a list of move(and the gap)
	private void actMore(int gap,ImageIcon ... move)
	{
		try
		{
			for(int i=0;i<move.length;i++)
			{
				Thread.sleep(gap);
				act(move[i]);
			}
		}
		catch(InterruptedException e){return;}
	}

	private class talk extends JDialog
	{
		private int len,lineN,maxNperL=30,width;
		private JPanel bgp;
		public talk(String contain)
		{
			len=contain.length();
			if(len<=maxNperL)
			{
				width=contain.length()*20+10;
				lineN=1;
			}
			else
			{
				width=(maxNperL*20)+10;
				lineN=((len-len%maxNperL)/maxNperL)+1;
			}

			//change the GUI style first
			String laf = "javax.swing.plaf.nimbus.NimbusLookAndFeel";  
	        try {  
	            UIManager.setLookAndFeel(laf);  
	            SwingUtilities.updateComponentTreeUI(this);  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        }
			
			//whole programe stop when the login is closed
			addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				});

			//setDefaultLookAndFeelDecorated(true);
			setResizable(false);
			setUndecorated(true);
			setBackground(new Color(255,255,255,150));
			this.setAlwaysOnTop(true);

			//background picture layer
			bgp=new JPanel();
			bgp.setOpaque(false);
			bgp.setLayout(null);

			//text area
			JLabel aha;
			int i;
			for(i=0;i<lineN;i++)
			{

				if(i!=lineN-1)
					aha=new JLabel(contain.substring(i*maxNperL,(i+1)*maxNperL));
				else
					aha=new JLabel(contain.substring(i*maxNperL));
				aha.setFont(new Font("ITALIC",Font.PLAIN,20));
				aha.setBounds(5,i*20+5,width,20);
				bgp.add(aha);
			}
			setLocation(nowx,nowy-((i)*20+5));
			setSize(width,(i)*20+5);
			add(bgp);
			setVisible(true);
		}
	}
}
