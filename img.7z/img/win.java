import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.*;

public class win
{
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				MyFrame frame=new MyFrame();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}

class MyFrame extends JFrame
{
	private int F_WIDTH;
	private int F_HEIGHT;
	private int nowx,nowy,status=0;

	static private JFrame here;
	private JLabel rumia;
	private JPanel jpp;
	private int direction=0;//0 to left

	private ImageIcon left_stand,left_run1,left_run2, 
			right_stand,right_run1,right_run2,look,look2, //walk and stand
			left_fly,right_fly,left_down,right_down, //fly and stop
			left_sit_normal,right_sit_normal, //normal sit
			hah1,hah2,hah3,hah4,hah5,hah12,hah22,hah32,hah42,hah52, //tired and hah
			left_sano,right_sano,//look at the sky
			shink1,shink2,shink3,shink4,shink12,shink22,shink32,shink42;

	public MyFrame()
	{
		this.here=this;
		String laf = "javax.swing.plaf.nimbus.NimbusLookAndFeel";  
        try {  
            UIManager.setLookAndFeel(laf);  
            SwingUtilities.updateComponentTreeUI(this);  
        } catch (Exception e) {
            e.printStackTrace();  
        }

        addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});

        //move
        left_stand=new ImageIcon("material/move/shime1.png");right_stand=new ImageIcon("material/move/shime12.png");
        left_run1=new ImageIcon("material/move/shime2.png");right_run1=new ImageIcon("material/move/shime22.png");
		left_run2=new ImageIcon("material/move/shime3.png");right_run2=new ImageIcon("material/move/shime32.png");
		left_fly=new ImageIcon("material/move/shime4.png");right_fly=new ImageIcon("material/move/shime42.png");
		left_down=new ImageIcon("material/move/shime5.png");right_down=new ImageIcon("material/move/shime52.png");
		look=new ImageIcon("material/move/look.png");look2=new ImageIcon("material/move/look2.png");
		//sit
		left_sit_normal=new ImageIcon("material/sit/normal.png");right_sit_normal=new ImageIcon("material/sit/normal2.png");
		hah1=new ImageIcon("material/sit/hah1.png");hah12=new ImageIcon("material/sit/hah12.png");
		hah2=new ImageIcon("material/sit/hah2.png");hah22=new ImageIcon("material/sit/hah22.png");
		hah3=new ImageIcon("material/sit/hah3.png");hah32=new ImageIcon("material/sit/hah32.png");
		hah4=new ImageIcon("material/sit/hah4.png");hah42=new ImageIcon("material/sit/hah42.png");
		hah5=new ImageIcon("material/sit/hah5.png");hah52=new ImageIcon("material/sit/hah52.png");
		left_sano=new ImageIcon("material/sit/sano.png");right_sano=new ImageIcon("material/sit/sano2.png");
		shink1=new ImageIcon("material/sit/shink.png");shink12=new ImageIcon("material/sit/shink12.png");
		shink2=new ImageIcon("material/sit/shink2.png");shink22=new ImageIcon("material/sit/shink22.png");
		shink3=new ImageIcon("material/sit/shink3.png");shink32=new ImageIcon("material/sit/shink32.png");
		shink4=new ImageIcon("material/sit/shink4.png");shink42=new ImageIcon("material/sit/shink42.png");

        //setDefaultLookAndFeelDecorated(true);
		setResizable(false);
		setUndecorated(true);
		setLocation(400,200);
		setSize(128,128);
		setBackground(new Color(0,0,0,0));
		this.setAlwaysOnTop(true); 

		Dimension screensize=Toolkit.getDefaultToolkit().getScreenSize();
		F_WIDTH=screensize.width;
		F_HEIGHT=screensize.height;

		this.jpp=new JPanel();
		jpp.setOpaque(false);
		jpp.setLayout(null);

		rumia=new JLabel(left_stand);
		rumia.setBounds(0,0,128,128);
		jpp.add(rumia);


		add(this.jpp);

		nowx=400;
		nowy=200;

		Runnable r=new rumiaMove();
		Thread t=new Thread(r);
		t.start();
	}

	private class rumiaMove implements Runnable
	{
		private Random random=new Random();
		private int v,mod,flag;
		public void run()
		{
			while(true)
			{
				//move status
				try
				{
					if(status==0)
					{
						mod=random.nextInt(10);
						//left walk
						if(mod==1)
						{
							if(direction==1)
							{
								act(left_stand);
								direction=0;
							}

							int walkx=random.nextInt(200);
							if(nowx-walkx<0)
							{
								walkx=nowx;
							}
							//tary=random.nextInt(600);
							int x=0;
							for(flag=0;x<=walkx;x+=5)
							{
								Thread.sleep(200);
								switch(flag)
								{
									case 0:act(left_run1);flag++;break;
									case 1:act(left_stand);flag++;break;
									case 2:act(left_run2);flag++;break;
									case 3:act(left_stand);flag=0;break;
								}
								here.setLocation(nowx-x,nowy);
							}
							nowx-=x;
							act(left_stand);
						}
						//right walk
						else if(mod==2)
						{
							if(direction==0)
							{
								act(right_stand);
								direction=1;
							}

							int walkx=random.nextInt(200);
							if(nowx+walkx+128>F_WIDTH)
							{
								walkx=F_WIDTH-nowx-128;
							}
							int x=0;
							for(flag=0;x<=walkx;x+=5)
							{
								Thread.sleep(200);
								switch(flag)
								{
									case 0:act(right_run1);flag++;break;
									case 1:act(right_stand);flag++;break;
									case 2:act(right_run2);flag++;break;
									case 3:act(right_stand);flag=0;break;
								}
								here.setLocation(nowx+x,nowy);
							}
							nowx+=x;
							act(right_stand);
						}
						//fly up
						else if(mod==3)
						{
							if(direction==0)
								act(left_fly);
							else
								act(right_fly);
							int walky=random.nextInt(300);
							if(nowy-walky<0)
							{
								walky=nowy;
							}
							int y=0;
							for(flag=0;y<=walky;y+=5)
							{
								Thread.sleep(100);
								here.setLocation(nowx,nowy-y);
							}
							nowy-=y;
							if(direction==0)
								actMore(150,left_down,left_stand);
							else
								actMore(150,right_down,right_stand);
						}
						//fly down
						else if(mod==4)
						{
							if(direction==0)
								act(left_fly);
							else
								act(right_fly);
							int walky=random.nextInt(400);
							if(nowy+walky+128>F_HEIGHT)
							{
								walky=F_HEIGHT-nowy-128;
							}
							int y=0;
							for(flag=0;y<=walky;y+=5)
							{
								Thread.sleep(100);
								here.setLocation(nowx,nowy+y);
							}
							nowy+=y;
							if(direction==0)
								actMore(150,left_down,left_stand);
							else
								actMore(150,right_down,right_stand);
						}
						//switch status to sit
						else if(mod==5)
						{
							//sit
							status=1;
							if(direction==0)
								act(left_sit_normal);
							else
								act(right_sit_normal);
						}
						else
						{
							if(direction==0)
								act(look);
							else
								act(look2);
							Thread.sleep((1+random.nextInt(2))*1000);
							if(direction==0)
								act(left_stand);
							else
								act(right_stand);
						}
					}
					//sit status
					else if(status==1)
					{
						mod=random.nextInt(8);
						//switch status to move
						if(mod==1)
						{
							status=0;
							if(direction==0)
								act(left_stand);
							else
								act(right_stand);
						}
						//hah~~(tired)
						else if(mod==2)
						{
							if(direction==0)
							{
								actMore(300,hah1,hah2);
								Thread.sleep(1000);
								actMore(300,hah3,hah4,hah5,left_sit_normal);
							}
							else
							{
								actMore(300,hah12,hah22);
								Thread.sleep(1000);
								actMore(300,hah32,hah42,hah52,right_sit_normal);
							}
							Thread.sleep((1+random.nextInt(2))*1000);
						}
						//comes up a good idea
						else if(mod==3)
						{
							if(direction==0)
								act(left_sano);
							else
								act(right_sano);
							Thread.sleep((1+random.nextInt(2))*1000);
						}
						//shrink legs
						else if(mod==4)
						{
							int t=random.nextInt(10);
							if(direction==0)
							{
								actMore(500,shink1,shink2);
								for(int i=0;i<t;i++)
								{
									actMore(400,shink3,shink2,shink4,shink2);
								}
								act(shink2);
							}
							else
							{
								actMore(500,shink12,shink22);
								for(int i=0;i<t;i++)
								{
									actMore(400,shink32,shink22,shink42,shink22);
								}
								act(shink22);
							}
						}
						else
						{
							if(direction==0)
								act(left_sit_normal);
							else
								act(right_sit_normal);
							Thread.sleep((2+random.nextInt(4))*1000);
						}
					}
				}
				catch(InterruptedException e){return ;}
			}
		}
	}

	private void act(ImageIcon move)
	{
		this.rumia.setIcon(move);
		//this.jpp.updateUI();
	}

	private void actMore(int gap,ImageIcon ... move)
	{
		try
		{
			for(int i=0;i<move.length;i++)
			{
				Thread.sleep(gap);
				act(move[i]);
			}
		}
		catch(InterruptedException e){return;}
	}
}
